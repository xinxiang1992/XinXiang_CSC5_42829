/* 
 * File:   main.cpp
 * Author: Xin Xiang
 *
 * Created on April 28, 2016, 1:15 PM
 * Purpose: Project 1
 */

//System Libraries
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
#include <fstream>


using namespace std;
//User Libraries


 const int COL=2;
 
//Function Prototype
int boss1(int,int, int);
void bossfight(int,int, int);
void boss2fight(int,int,const int);
void printA(int [][COL], int b);
void mrkSort(int [],int);//Sort the whole array
void smlNLst(int [],int, int);//Find smallest in list from a position
void swap(int &,int &);//Swap elements


//Execution Starts Here
/*
 * 
 */
int main(int argc, char** argv) {
    //Set up random number seed
    srand(static_cast<unsigned int>(time(0)));
   
    ofstream input;
    
    input.open("record.dat");
    
    cout<<"Welcome To Your Journey."<<endl;
    cout<<endl<<endl;
    
    char a;//choice that you are going to make
    cout<<"Start or not?? Press any keys to start. "<<
            "Press N or n to quit."<<endl;
    
    //Input "no" choice
    cin>>a;
    if(a=='n'||a=='N')
    {
        cout<<"Game Over!!!"<<endl;
        return 0;
    }
    
    //Introduction to the character
    cout<<"Your Initial Condition: "<<endl; 
    
    //Declare Variables;
    int hp=500,mp=50;//Health Pool, Mana Pool, Experience Pool
    
    //output initial condition of character
    cout<<"HP: "<<hp<<setw(4)<<"   MP: "<<mp<<"    Basic Damage: 55-60."<<endl;
    
    boss1(hp,mp,COL);
    input<<"Game's Over!!"<<endl;
    
    
    input.close();
    return 0;
}

/**************************Make choice to fight or not*************************/
int boss1(int a,int b, int c)
{
    char choice;
    cout<<"You met a boss. You want to fight or not."
            <<" Press n to escape, Press y to fight."<<endl;
    cin>>choice;
    //Make decision to fight with boss or not
    switch(choice)
    {
        case 'Y':
        case 'y': bossfight(a,b,c);break;
        
        case 'N':
        case 'n': 
        {
            cout<<"You decide to choose a small path to avoid the boss, ";
            cout<<"but you die because of spike trap."<<endl;break;
        }
    }
    return a,b;
}

/********************Start to fight with the first boss************************/
void bossfight(int c,int d, int e)
{
    //c is character's HP, d is character's MP
    
    int bossHP=500;//Boss's initial HP
    
    while(bossHP>0&&c>0)
    {
        //Character's round to hit boss
        cout<<"You just hit the boss."<<endl;
        
        int damCha=rand()%6+55;//Character's random damage
        bossHP=bossHP-damCha;//Boss's hp left
        
        cout<<"You just made "<<damCha<<" on the boss."<<endl;
        
        //Boss' round to hit character
        cout<<"Boss Hit you."<<endl;
        int damBos=rand()%6+25;//Boss's random damage
        c=c-damBos;//Character's hp left
        cout<<"Boss just made "<<damBos<<" damage."<<endl;
        cout<<"Character's current HP is "<<c<<endl;
        cout<<endl<<endl;
    }
    bool x;
    if(c>0) x=true;
    if(x==true) cout<<"You defeated Boss."<<endl;
    char de;
    cout<<"Do you want to continue?"<<endl;
    cin>>de;
    if(de=='y'||de=='Y')
    {
       //Second Boss Fight
    boss2fight(c,d,e);  
    }
    else
    {
        cout<<"Game Over. You Haven't Finished Your Journey."<<endl;
    }
    
   
    
}

/************************Second Boss Fight************************************/
void boss2fight(int c,int d, const int e)
{
    
    int count=0; //The number of rounds that they fight.
    int fight3[20];
    int fight4[20];
    cout<<"After a long travel, you meet a another Boss, Roshan."<<endl<<endl;
    cout<<"The Battle Begins."<<endl;
    int roshanHP=2000;//Roshan's Basic HP
    
    int i=1;//Character only can use once of HP flask.
    int j=1;//Character only once of ultima spell
    //HP flask taking
    while(roshanHP>0&&c>0)
    {
        
        //Have HP Flask
        while(c<=150&&i<2)
        {
              
                char deci;//make the decision to take hp flask or not
                cout<<"Warning!! Your HP is too low, have HP Flask?"<<endl;
                cout<<"Press Y to use. Press N to ignore."<<endl;
                cin>>deci;
                if(deci=='y'||deci=='Y')
                {
                    c=500;
                    cout<<"Your HP is full Now."<<endl;
                }
                i++;
            
        }
        
        //Character's round to hit boss
        cout<<"You just hit the Roshan."<<endl;
        
        int damCha=rand()%6+55;//Character's random damage
        roshanHP=roshanHP-damCha;//Boss's hp left
        
        cout<<"You just made "<<damCha<<" on the Roshan."<<endl;
        
        //Roshan' round to hit character
        cout<<"Roshan Hit you."<<endl;
        int damBos=rand()%6+25;//Roshan's random damage
        c=c-damBos;//Character's hp left
        cout<<"Roshan just made "<<damBos<<" damage."<<endl;
        cout<<"Character's current HP is "<<c<<endl;
        
        cout<<endl<<endl;
        
         //Mana flask 
        while(c<80&&j<2)
        {
            cout<<"Roshan is invincible. Want to use Death Finger (Only Once for Life Time."<<endl;
            char deci;
            cout<<"Press Y to use. Press N to ignore."<<endl;
            cin>>deci;
            if(deci=='Y'||deci=='y')
            {
                cout<<"You made 1000 damage."<<endl;
                roshanHP=roshanHP-1000;
            }
            j++;
        }
        
        fight3[count]=damCha;
        
        fight4[count]=damBos;
        
        count++;
    }
    bool x;
    if(c>0) x=true;
    if(x==true) cout<<"You defeated Boss."<<endl;
    else cout<<"You have been Defeated."<<endl;
    
    mrkSort(fight3, count);//Array of character's damage
    mrkSort(fight4, count);//Array of boss' damage.
    
    
    
    //fill a 2D array
    int arr[count][COL];
    
    for(int i=0; i<count; i++){
        arr[i][0]= fight3[i];
        arr[i][1]= fight4[i];
    }
    
    printA(arr, count);
}



void mrkSort(int a[],int n){
    
    for(int i=0;i<n-1;i++){
        
        smlNLst(a,n,i);
    }
}

void smlNLst(int c[],int l,int pos){
    
    for(int i=pos+1;i<l;i++){
        
        if(c[pos]>c[i])swap(c[pos],c[i]);
    }
}

void swap(int &a,int &b){
    
    a=a^b;
    b=a^b;
    a=a^b;
}

void printA(int a[][COL], int b){
    
    cout<<"The damage for both player and boss in numerical order"<<endl;
    cout<<"Player's damage      Boss' damage"<<endl;
    
    for(int i=0; i<b; i++){
        cout<<setw(7)<<a[i][0]<<"           "<<a[i][1]<<endl;
    }
}