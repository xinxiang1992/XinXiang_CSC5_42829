/* 
 * File:   main.cpp
 * Author: Xin Xiang
 * Created on March 7, 2016, 9:39 AM
 * Purpose: Monthly Payments
 */
//System Libraries
#include <iostream>
#include <cmath>
using namespace std;
//User Libraries
//Global Constants

//System Starts Here

int main(int argc, char** argv) {
    //Declare Variables
    
    //Loan Amount, Monthly Interest Rate, Number of Payments
    float l, r, n; 
    
    //Monthly payment, Amount paid back, Interest Paid
    float p;
    
   //Input and Outout Results
            
            cout<<"The loan is ";
            cin>>l;
            
            
            cout<<"The monthly interest rate is ";
            cin>>r;
           
            
            cout<<"The number of payments is ";
            cin>>n;
            
            
            p=((r*pow(1+r,n)/(pow(1+r,n)-1)))*l;
            
            cout<<"The payment is "<<p<<endl;
            
            float loan_check;
            
            //Calculate Loan Check
            loan_check=(p*(pow(1+r,n)-1))/(r*pow(1+r,n));
            
            cout<<"The loan check is "<<loan_check<<endl;
            
            //Exit Stage Right
            
        

    return 0;
}

